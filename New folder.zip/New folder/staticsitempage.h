#ifndef STATICSITEMPAGE_H
#define STATICSITEMPAGE_H

#include <QDialog>
#include <QButtonGroup>
#include <QPainter>
#include <QHBoxLayout>
#include <QLabel>
#include <QListWidgetItem>

namespace Ui {
class StaticsItemPage;
}

class StaticsItemPage : public QDialog
{
    Q_OBJECT

public:
    explicit StaticsItemPage(QWidget *parent = nullptr);
    ~StaticsItemPage();

private:
    Ui::StaticsItemPage *ui;
    QButtonGroup *regionGroup;
    QButtonGroup *typeGroup;

    void refresh_leaderboard();
    QString format_duration(int totalSeconds);
    void refresh_history();
    void refresh_character_stats();
    void paintEvent(QPaintEvent *event);
    QSize main_size;
    QSize sub_page_size;
    void resize_and_center(QSize newSize);

};

#endif // STATICSITEMPAGE_H
